<?php

$page_title="page d'accueil ";
$message=" bienvenue mon ami sur cette page ";
require_once "views/index.php";